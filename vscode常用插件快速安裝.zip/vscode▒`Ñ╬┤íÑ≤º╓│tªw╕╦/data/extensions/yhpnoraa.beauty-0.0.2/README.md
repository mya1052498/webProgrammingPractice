# Beauty 
Beauty is a code beautifier extension for VSCODE among Web Developing. It supports lots kinds of language, such as javascript,css,less,python,jsx,markups(html,swig,nunjucks)...etc...

## Features

Just beautify and format you code in your workspace.

>javascipt(ES6),JSX
 ![](https://gw.alicdn.com/tfs/TB1lR.AigMPMeJjy1XdXXasrXXa-1116-526.gif)
>css,less,scss
 ![](https://gw.alicdn.com/tfs/TB1VN4hiwMPMeJjy1XcXXXpppXa-1116-526.gif)
>html
 ![](https://gw.alicdn.com/tfs/TB12QQAigMPMeJjy1XdXXasrXXa-1116-526.gif) 
>nunjucks
 ![](https://gw.alicdn.com/tfs/TB1TQgAigMPMeJjy1XdXXasrXXa-1116-526.gif)

## Usage

Select you code. and type ```Cmd+Shift+B``` or ```Cmd+Shift+P``` & select ```beauty```, like this:

![](https://gw.alicdn.com/tfs/TB1IwoDigMPMeJjy1XdXXasrXXa-1116-526.gif)

## Requirements

 No requirements.

## Extension Settings

 No settings.

### For more information, welcome to contact me.

* My email: aaronphy@163.com.
* If you want to work with me and work in Alibaba. Please send me your resume to ```mafe.mf@alibaba-inc.com```

**Enjoy!**