# README
## install it
[see here](https://code.visualstudio.com/docs/editor/extension-gallery)

`ext install AutoFileName`

### How to use
![demo](https://trello-attachments.s3.amazonaws.com/56c86fd76bf599f4fa62ee7f/1152x720/4b439177b0fb1c04af133aa733ba2a09/Untitled.gif)

## If there is any bug, give me an issue on [github](https://github.com/s6323859/vscode-autofilename) please.

### 0.1.3
Fix for Windows  

### 0.0.7
Change icon

### 0.0.6
Add icon

### 0.0.5
Edit README

### 0.0.4
**Fixed Bug!**

### 0.0.3
Add home page into package.json

###0.0.2
Add README

###0.0.1
Complete feature!

** Enjoy!**
